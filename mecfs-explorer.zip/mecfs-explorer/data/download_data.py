"""
Download public ME/CFS datasets referenced in PROJECT_PLAN.md.

Two real, working sources are wired up here:

1. GEO (Gene Expression Omnibus) — via GEOparse. Good for the transcriptomics /
   methylation datasets (GSE14577, GSE16059, GSE59489, GSE93266, GSE128078).
2. Metabolomics Workbench REST API — https://www.metabolomicsworkbench.org/rest/
   Good for study metadata/factors. Full raw data tables for a given study are
   fetched with the same API but are often easier to get as the paper's
   supplementary Excel/CSV files — this script tells you when that's the case.

Usage:
    python data/download_data.py --list
    python data/download_data.py --geo GSE59489
    python data/download_data.py --mw ST001849
"""

import argparse
import json
import sys
from pathlib import Path

import requests

RAW_DIR = Path(__file__).parent / "raw"
RAW_DIR.mkdir(exist_ok=True)

MW_BASE_URL = "https://www.metabolomicsworkbench.org/rest"

# What's available and how to get it. Keep this list honest — some entries are
# "go get the supplementary file by hand", which is a normal part of working
# with small clinical/omics studies, not a bug in this script.
DATASETS = {
    "GSE14577": {
        "description": "PBMC gene expression, post-viral CFS (n=8) vs healthy (n=7)",
        "source": "GEO",
        "note": "Small — good for practicing small-N cross-validation.",
    },
    "GSE16059": {
        "description": "Monozygotic twins discordant for chronic fatigue (44 pairs)",
        "source": "GEO",
        "note": "Original study found NO significant differential expression — "
        "good for a paired-sample / null-result exercise.",
    },
    "GSE59489": {
        "description": "DNA methylation (450K array) in ME/CFS PBMCs",
        "source": "GEO",
        "note": None,
    },
    "GSE93266": {
        "description": "DNA methylome, larger ME/CFS cohort",
        "source": "GEO",
        "note": None,
    },
    "GSE128078": {
        "description": "Whole-blood RNA-seq before/after exercise challenge "
        "(14 cases, 11 controls, longitudinal)",
        "source": "GEO",
        "note": "Time-series — good for the exercise-challenge research question.",
    },
    "ST001849": {
        "description": "Metabolomics Workbench: Lipkin/Columbia plasma metabolomics "
        "+ fecal metagenomics (50 cases, 50 controls) — verify the exact "
        "study ID on metabolomicsworkbench.org before relying on this.",
        "source": "METABOLOMICS_WORKBENCH",
        "note": "This script fetches summary + factors (metadata). For the full "
        "analyte-level data table, use the 'data' output item once you've "
        "confirmed the right AN (analysis) ID on the study's Workbench page.",
    },
    "CHE2022_METABOLOMICS": {
        "description": "Che et al. 2022 plasma metabolomics, 106 ME/CFS cases, "
        "91 controls, 888 analytes — the best-powered public ME/CFS omics dataset",
        "source": "MANUAL",
        "note": "Not a single clean download. Get the supplementary data tables "
        "from the paper: https://pmc.ncbi.nlm.nih.gov/articles/PMC9320121/ "
        "(check the 'Supplementary Materials' section for the analyte matrix). "
        "Save whatever you download into data/raw/che2022/.",
    },
    "NHANES": {
        "description": "CDC NHANES — general population survey, includes "
        "self-reported fatigue / functional-limitation items (no ME/CFS "
        "diagnosis field, but useful as a large practice dataset before the "
        "small clinical ones)",
        "source": "MANUAL",
        "note": "Browse and download component files (.XPT) directly from "
        "https://wwwn.cdc.gov/nchs/nhanes/ — pick a cycle, then the "
        "Questionnaire component for fatigue-related items.",
    },
}


def list_datasets() -> None:
    print(f"{'ID':<22} {'Source':<22} Description")
    print("-" * 90)
    for key, meta in DATASETS.items():
        print(f"{key:<22} {meta['source']:<22} {meta['description']}")
        if meta["note"]:
            print(f"{'':<22} {'':<22} note: {meta['note']}")
    print(
        "\nRun with --geo <ID> or --mw <ID> to fetch. MANUAL entries need a "
        "browser — the note above tells you where."
    )


def download_geo(accession: str) -> None:
    try:
        import GEOparse
    except ImportError:
        sys.exit("Install GEOparse first: pip install GEOparse")

    dest = RAW_DIR / accession
    dest.mkdir(exist_ok=True)
    print(f"Downloading {accession} from GEO into {dest} ...")
    gse = GEOparse.get_GEO(geo=accession, destdir=str(dest))
    # Dump each sample's phenotype/expression table so you have something to
    # load with pandas straight away.
    for gsm_name, gsm in gse.gsms.items():
        gsm.table.to_csv(dest / f"{gsm_name}_table.csv", index=False)
    meta_path = dest / "series_metadata.json"
    meta_path.write_text(json.dumps(gse.metadata, indent=2, default=str))
    print(f"Done. {len(gse.gsms)} samples written to {dest}")


def download_metabolomics_workbench(study_id: str) -> None:
    dest = RAW_DIR / study_id
    dest.mkdir(exist_ok=True)

    for output_item in ("summary", "factors"):
        url = f"{MW_BASE_URL}/study/study_id/{study_id}/{output_item}"
        print(f"GET {url}")
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        out_path = dest / f"{output_item}.json"
        out_path.write_text(resp.text)
        print(f"  saved -> {out_path}")

    print(
        "\nSummary + factors saved. For the full data matrix, find the study's "
        "analysis (AN######) ID on its Metabolomics Workbench page, then fetch:\n"
        f"  {MW_BASE_URL}/study/analysis_id/AN######/data\n"
        "and save the result yourself — the shape varies enough by study that "
        "it's worth checking before scripting it blindly."
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--list", action="store_true", help="List known datasets")
    parser.add_argument("--geo", metavar="ACCESSION", help="Download a GEO series, e.g. GSE59489")
    parser.add_argument(
        "--mw", metavar="STUDY_ID", help="Download Metabolomics Workbench metadata, e.g. ST001849"
    )
    args = parser.parse_args()

    if args.list or not (args.geo or args.mw):
        list_datasets()
        return

    if args.geo:
        download_geo(args.geo)
    if args.mw:
        download_metabolomics_workbench(args.mw)


if __name__ == "__main__":
    main()
